importScripts("./auth.js", "./preferences.js");
